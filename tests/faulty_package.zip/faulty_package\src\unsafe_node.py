#!/usr/bin/env python3 
FAULTY ROS PACKAGE - Should fail validation 
import time  # Wrong sleep function 
 
# Missing ROS init 
# rospy.init_node('unsafe_node') 
 
joint = [0.0, 10.0, 0.0, 0.0, 0.0, 0.0]  # Unsafe value 
 
while True:  # Infinite loop 
    time.sleep(0.1)  # Blocking sleep 
    # Missing break condition 
