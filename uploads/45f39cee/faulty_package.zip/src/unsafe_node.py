#!/usr/bin/env python3
# Faulty ROS package with intentional errors

import time

# Missing init_node
# Infinite loop
while True:
    time.sleep(0.1)
    x = 1/0  # Crash
