#!/usr/bin/env python3
# MOCK ROS NODE for assignment
class MockROSPy:
    @staticmethod
    def init_node(name, anonymous=False): print("[MOCK] Node init:", name)
    @staticmethod
    def loginfo(x): print("[INFO]", x)
    @staticmethod
    def logerr(x): print("[ERR]", x)
    @staticmethod
    def sleep(x): pass
    @staticmethod
    def is_shutdown(): return False
    class ROSInterruptException(Exception): pass

class MockMsg: pass

try:
    import rospy
except:
    rospy = MockROSPy

def main():
    rospy.init_node('pick_and_place')
    rospy.loginfo("Running mock pick-and-place node")

if __name__ == "__main__":
    main()
